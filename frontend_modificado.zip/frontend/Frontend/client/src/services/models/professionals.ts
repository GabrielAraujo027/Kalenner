export interface ProfessionalResponse {
  id: number;
  name: string;
  description: string;
  companyId: string;
}
